## React Native Taxi App- Backend v4.2.1

Thanks for purchasing the ExpressJs ,SocketIo empowered TaxiApp.

Follow the documentation to install and get started with the development:

-   [Documentation](https://docs.market.nativebase.io/react-native-taxi-app-with-backend/)
-   [Product Page](http://strapmobile.com/react-native-uber-like-app-backend/)

Happy coding!
